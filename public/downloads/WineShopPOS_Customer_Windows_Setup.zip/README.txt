WineShopPOS Windows App Setup
=============================

Requirements
- Windows PC
- Microsoft Edge installed
- Internet connection

Install
1. Extract this ZIP.
2. Double-click WineShopPOS_Windows_App_Setup.cmd.
3. WineShopPOS shortcuts are created on Desktop and Start Menu.
4. Use the WineShopPOS shortcut going forward.

Remove shortcuts
- Double-click WineShopPOS_Windows_App_Remove.cmd.

Administrator access is not required.
The setup creates shortcuts only and opens:
https://wineshoppos.z29.web.core.windows.net/
